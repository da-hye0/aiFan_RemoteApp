package com.example.myapplication.base;

public interface OnItemClickListener {

    void onItemClick(int position);
}
